package org.example.tp3.exo1;

public interface UserRepository {
    User findUserById(long id);
}
