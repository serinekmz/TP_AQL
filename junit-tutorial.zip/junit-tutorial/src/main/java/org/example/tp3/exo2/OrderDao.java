package org.example.tp3.exo2;

public interface OrderDao {
    void saveOrder(Order order);
}
