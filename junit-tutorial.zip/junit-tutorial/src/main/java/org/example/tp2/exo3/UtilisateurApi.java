package org.example.tp2.exo3;

public interface UtilisateurApi {
    boolean creerUtilisateur(Utilisateur utilisateur);
    int obtenirIdUtilisateur(Utilisateur utilisateur);
}
