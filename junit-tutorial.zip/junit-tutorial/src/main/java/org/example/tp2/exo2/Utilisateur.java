package org.example.tp2.exo2;

public class Utilisateur {
    private String prenom;
    private String nom;
    private String email;

    public Utilisateur(String prenom, String nom, String email) {
        this.prenom = prenom;
        this.nom = nom;
        this.email = email;
    }
}
