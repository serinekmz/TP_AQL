package org.example.tp2.exo3;

public class ServiceException extends RuntimeException {
    public ServiceException(String message) {
        super(message);
    }
}