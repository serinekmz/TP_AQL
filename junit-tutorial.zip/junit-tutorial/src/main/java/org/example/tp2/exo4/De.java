package org.example.tp2.exo4;

public interface De {
    int lancer();
}