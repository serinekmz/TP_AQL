package org.example.tp2;

public class Calculatrice {
    public int additionner(int a, int b) {
        result = a + b ;
        return result;
    }
    private int result ;
}
